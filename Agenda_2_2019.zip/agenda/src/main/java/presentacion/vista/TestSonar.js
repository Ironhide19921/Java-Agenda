

const pi = "yes, please";
pi = 3.14;  // Noncompliant

